﻿using Microsoft.AspNetCore.Identity;

namespace BlazingPizza;

public class PizzaStoreUser : IdentityUser
{
}